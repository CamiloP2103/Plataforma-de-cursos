class Config:
    SECRET_KEY = 'clave_secreta'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://UserPlataforma:Hola12@172.31.6.90/plataformacursos'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
